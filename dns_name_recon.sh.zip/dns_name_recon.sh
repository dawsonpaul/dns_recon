#!/bin/bash

externalDns="8.8.8.8"
internalDns="10.53.9.63"
 
echo line, extIp, intIp, openPortsExt, cnameResult, certName, certDate, curlHTTPServer, curlHTTPResponse, urlRedirectHTTP, curlHTTPSResponse, urlRedirectHTTPS, nameServers, whoisLookup;

while read -r line 
do

 extIp=$(dig $line @"$externalDns" | grep -v '8.8.8.8' |grep -m 1 -oE '((1?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\.){3}(1?[0-9][0-9]?|2[0-4][0-9]|25[0-5])' | tr -d ' ' )

 intIp=$(dig $line @"$internalDns" | grep -v 10.53.9.63 |grep -m 1 -oE '((1?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\.){3}(1?[0-9][0-9]?|2[0-4][0-9]|25[0-5])' | tr -d ' ')

 openPortsExt=$(nmap -v  -Pn -p 443,80 -oG - "$extIp"  | awk '/open/{print $5 " " $6}' | sed -e 's/\//-/g' -e 's/---//g' -e 's/,/|/g')

 openPortsInt=$(nmap -v -Pn -p 443,80 -oG - "$intIp"  | awk '/open/{print $5 " " $6}' | sed -e 's/\//-/g' -e 's/---//g' -e 's/,/|/g' )
 
 cnameResult=$(echo $(dig @"$externalDns" $line -t CNAME  +short))

 curlHTTPResponse=$(curl -m 3 -i -s  $line | head -1 | sed -e 's/\r//g' )

 curlHTTPSResponse=$(curl -m 3 -i -s  https://$line | head -1 | sed -e 's/\r//g' )

 curlHTTPServer=$(curl -m 3 -i -s  $line | grep 'Server:' | sed -e 's/\r//g')

 rootDom=$(echo $line | cut -d '.' -f2,3)

 nameServers=$(dig @8.8.8.8 $rootDom -t NS +short)
 
 whoisLookup=$(whois $extIp | grep -i 'netname\|orgname' | cut -d ":" -f2 | tr -d ' ' | tr -s ',' '.')

 certName=$(echo | timeout 10 openssl s_client -showcerts -servername $line -connect $line:443 2>/dev/null | openssl x509 -inform pem -noout -text | awk '/Subject Alternative Name/{getline; print}' | sed 's/DNS://g; s/,/;/g' | xargs)

 certDate=$(echo | timeout 10 openssl s_client -showcerts -servername $line -connect $line:443 2>/dev/null | openssl x509 -inform pem -noout -text | grep "Not After" | sed 's/Not After ://' | xargs)

 cnameIP=$(echo $(dig @"$externalDns" $cnameResult +short))

	
 urlRedirectHTTP=$( if [[ "$curlHTTPResponse" == *"30"* ]];

		then curl -m 3 -i -s  "$line" | sed -n 's/.*href="\([^"]*\).*/\1/Ip';

			fi)

urlRedirectHTTPS=$( if [[ "$curlHTTPSResponse" == *"30"* ]];

		then curl -m 3 -i -s  "$line" | sed -n 's/.*href="\([^"]*\).*/\1/Ip';

			fi)






 echo $line, $extIp, $intIp, $openPortsExt, $cnameResult, $certName, $certDate, $curlHTTPServer, $curlHTTPResponse, $urlRedirectHTTP, $curlHTTPSResponse, $urlRedirectHTTPS, $nameServers, $whoisLookup; 

done < dns_names_uniq